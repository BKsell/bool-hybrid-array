import sys
from bool_hybrid_array import Ask_BHA
import time,gc
def main():
    try:bha_path = sys.argv[1]
    except:bha_path = input('请把文件拖拽到此处：')
    try:
        gc.disable()
        s = time.perf_counter()
        result = Ask_BHA(bha_path)
        e = time.perf_counter()
        print(f"解析结果:\n{result}\n\n耗时:{e-s}")
        input("解析完成，按回车退出...")
    except (Exception,BaseException,MemoryError,OSError) as e:
        print(f"解析失败: {repr(e)}")
        input("按回车退出...")
    finally:
        gc.enable()
        gc.collect()

if __name__ == "__main__":
    main()