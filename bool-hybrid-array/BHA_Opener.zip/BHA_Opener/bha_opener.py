import sys
from bool_hybrid_array import Ask_BHA  # 导入你的库

def main():
    try:bha_path = sys.argv[1]  # 获取双击/选择的.bha文件路径
    except:bha_path = input('请把文件拖拽到此处：')
    try:
        result = Ask_BHA(bha_path)
        print(f"解析结果:\n{result}")
        input("解析完成，按回车退出...")  # 停留窗口方便查看
    except Exception as e:
        print(f"解析失败: {e}")
        input("按回车退出...")

if __name__ == "__main__":
    main()