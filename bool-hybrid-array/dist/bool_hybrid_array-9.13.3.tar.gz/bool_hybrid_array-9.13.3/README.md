# BoolHybridArray：高效的布尔混合数组库

[![月下载量](https://static.pepy.tech/badge/bool-hybrid-array/month)](https://pepy.tech/project/bool-hybrid-array)
[![周下载量](https://static.pepy.tech/badge/bool-hybrid-array/week)](https://pepy.tech/project/bool-hybrid-array)
[![总下载量](https://static.pepy.tech/badge/bool-hybrid-array)](https://pepy.tech/project/bool-hybrid-array)
[![GitHub Stars](https://img.shields.io/github/stars/BKsell/bool-hybrid-array?style=flat-square&logo=github)](https://github.com/BKsell/bool-hybrid-array)
[![GitHub Forks](https://img.shields.io/github/forks/BKsell/bool-hybrid-array?style=flat-square&logo=github)](https://github.com/BKsell/bool-hybrid-array)
[![GitHub License](https://img.shields.io/github/license/BKsell/bool-hybrid-array?style=flat-square)](LICENSE)
[![PyPI Version](https://img.shields.io/pypi/v/bool-hybrid-array?style=flat-square&logo=pypi)](https://pypi.org/project/bool-hybrid-array/)
[![PyPI Downloads](https://img.shields.io/pypi/dm/bool-hybrid-array?style=flat-square&logo=pypi)](https://pypi.org/project/bool-hybrid-array/)
[![Python Versions](https://img.shields.io/pypi/pyversions/bool-hybrid-array?style=flat-square&logo=python)](https://pypi.org/project/bool-hybrid-array/)


一个专为布尔值优化的数组类，能够根据数据特征自动在密集存储和稀疏存储模式间切换，兼顾性能和内存效率。

## ***注：大版本号更新并非不兼容更新，而是重大更新***

注：当API完全稳定时就会发布版本规则较严谨的new-1.0.0版本，预期为10.x或11.x版本结束后

***注意：目前社区中若存在名称类似（如包含 “bool-hybrid-array”+ 后缀、boolean\_array、validate.io-boolean-array）的库，均与本项目（bool-hybrid-array）无关联，本项目的所有功能设计、代码实现均为独立开发；***
***其他平台里的类似名库绝不是我的库***

***注意：若你的原bool-hybrid-array库版本<7.10.9，看到此版本请立即更新到>=7.10.9版本，其他版本的导入都有问题！！！***

作者：蔡靖杰（同维护者，PyPI账号Bkshell）

## 安装方法

使用uv安装（推荐，比pip快）：

```bash
#如果没有uv先安装uv
pip install uv
#先安装cython可选优化（非强制但推荐）
python -m uv pip install cython
#然后安装再bool-hybrid-array
python -m uv pip install bool-hybrid-array

```

## 更新方法

```bash

python -m uv pip install -U bool-hybrid-array

```

## 核心特性

* ✅**智能存储模式**：索引小的位置使用密集存储numpy.ndarray数组，索引大的位置为稀疏存储array.array稀疏数组
* ✅**反向稀疏模式**：数据大部分为非0（True）索引，稀疏区异常值为False
* ✅**稀疏模式**：数据大部分为0（False）索引，稀疏区异常值为True
* ✅```BoolHybridArr```函数会自动切换
* ✅**内存高效**：稀疏数据场景下比普通列表节省50%-80%内存
* ✅**操作便捷**：支持类似列表的索引、切片和赋值操作
* ✅**快速统计**：内置高效的计数和布尔判断方法
* ✅**速度优势**：修改元素的时间还不比list慢

## 快速开始

### 基本用法

```python

# 导入类

from bool_hybrid_array import *

# 创建实例

arr = BoolHybridArr([True, False, True, False, True])

arr2 = TruesArray(3)#7.9.0新增

arr3 = FalsesArray(3)#7.9.0新增

# 访问元素

print(arr[0])  # 输出: True；

print(arr[1:4])  # 输出:  BoolHybridArr([False, True, False])；

print(arr2)  # 输出:  BoolHybridArr([True, True, True])；

print(arr3)  # 输出:  BoolHybridArr([False, False, False])；
```

# 联系方式

* 若遇到 Bug 或有功能建议，可发送邮件至：1289270215@qq.com（更正规）
* 微信联系：18250730129（注：这是微信绑定的电话号码，优先微信沟通，请勿拨打电话哦）（微信联系回复最快）
* 抖音（绑定的电话号码同微信）（有讨论群，加入可讨论）
* 知乎：[贝壳 - 知乎](https://www.zhihu.com/people/50-78-41-74)
* CSDN：[BKsell-CSDN博客](https://blog.csdn.net/BKsell?spm=1000.2115.3001.5343)

# 仓库

GitHub仓库英文版：[bool-hybrid-array.git](https://github.com/BKsell/bool-hybrid-array.git)
GitHub仓库中文镜像：[1083175506-bool-hybrid-array](https://www.github-zh.com/projects/1083175506-bool-hybrid-array)

Gitee仓库：[bool-hybrid-array.git](https://gitee.com/BKsell/bool-hybrid-array.git)

GitCode仓库：[bool-hybrid-array.git](https://atomgit.com/BKsell/bool-hybrid-array.git)



# 修改元素

```python

arr[2] = False

print(arr)  # 输出: BoolHybridArr([True, False, False, False, True])

```

### 存储优化

```python

# 创建包含大量布尔值的数组（大部分为False）

big_arr = BoolHybridArr([i % 100 == 0 for i in range(10000)])

# 查看存储模式（此时应为稀疏模式）

print(repr(big_arr))  # 输出: BoolHybridArray(split_index=100, size=10000, is_sparse=True, small_len=101, large_len=98)

# 自动优化存储

big_arr.optimize()

```

### 其他功能

```python

# 统计True的数量

print(arr.count(True))  # 输出: 2

# 检查是否至少有一个True

print(any(arr))  # 输出: True

# 检查是否全为True

print(all(arr))  # 输出: False

# 复制数组（7.9.1新增）

arr_copy = arr.copy()

arr_copy[0] = False

print(arr[0])      # 输出: True（原数组不变）

print(arr_copy[0]) # 输出: False（拷贝数组已修改）

#寻找一个元素出现的索引(7.9.2新增)

arr_find = BoolHybridArr([i % 2 for i in range(10)])

print(arr_find.find(True))#输出：[1,3,5,7,9]

print(arr_find.find(False))#输出：[2,4,6,8,10]

# 查找第一个/最后一个出现的位置（7.10.3新增）

print(arr_find.index(True))   # 输出：1（第一个True的位置）

print(arr_find.rindex(True))  # 输出：9（最后一个True的位置）

#index/rindex的空数组处理（7.10.4新增）

none_arr =  BoolHybridArr([])

print(none_arr.index(True))#ValueError：无法在空的 BoolHybridArray 中查找元素

#查看是否需要优化（7.10.7新增，7.10.20+能用）

print(big_arr.memory_usage(detail=True))
'''样例输出（瞎编，但格式是这样）
{
    "总占用(字节)": 210,
    "密集区占用": 180,
    "稀疏区占用": 30,
    "对比原生list节省": "99.5%",
    "对比numpy节省": "79.0%",
    "是否需要优化": "是",
    "优化理由/说明": "稀疏区索引密度过高，优化后可转为密集存储提升速度"
}
'''
big_arr.optimize()  # 调用优化方法

print(big_arr.memory_usage(detail=True)["是否需要优化"])#"否"

'''当处理动态变化的布尔数组（如频繁增删元素）时，建议在关键操作后调用memory\_usage(detail=True)检查状态，通过optimize()保持最优性能。'''

#将数组转为int类型（7.11.0新增）：

print(int(arr))#输出：17（0b10001）

#位运算（7.13.0新增）

arr1 = BoolHybridArr([True, False, True, False])  # 0b1010

arr2 = BoolHybridArr([True, True, False, False])   # 0b1100

print(arr1 & arr2)  # 输出：BoolHybridArr([True,False,False,False])  # 0b1000

print(arr1 | arr2)  # 输出：BoolHybridArr([True,True,True,False])  # 0b1110

print([True, False] | arr1[:2])  # 反向运算：[True,False] | [True,False] → [True,False]

print(arr1 ^ arr2)  # 输出：BoolHybridArr([False,True,True,False])  # 0b0110

print(~arr1)  # 输出：BoolHybridArr([False,True,False,True])  # 0b0101（对应整数 ~10 = -11 的二进制布尔逻辑）

arr = BoolHybridArr([True, False, True])  # 0b101

arr <<= 2  # 左移2位：尾部补2个False → [True,False,True,False,False]（0b10100）

print(arr)

arr >>= 3  # 右移3位：尾部删3个元素 → [True,False]（0b10）

print(arr)

print(arr << -1)  # 负数左移：等价于右移1位 → [True]

#兼容numpy数组（8.0.0版本新增）

arr_BoolHybridArray = BoolHybridArr(\[])
arr_BoolHybridArray <<= 10
arr_BoolHybridArray <<= 10000
array_numpy = np.array([arr_BoolHybridArray,arr_BoolHybridArray])

#支持哈希（8.2.0版本新增）

set_ = {arr_BoolHybridArray}#不会报错呦

```

# ***v9.0.0重大更新***

```python
import numpy as np
import bool_hybrid_array

_2darr = BHA_List([BoolHybridArr([1,0,0,0,1],Type = BHA_Bool),TruesArray(5,Type = bool),FalsesArray(5,Type = np.bool_)])

print(_2darr)'''输出：

BHA_List([
BoolHybridArr([True,False,False,False,True]),
BoolHybridArr([True,True,True,True,True]),
BoolHybridArr([False,False,False,False,False]),
])
'''

#BoolHybridArray是布尔数组，那是什么布尔数组呢？numpy.bool_？原生bool？其他库的布尔类型？还是本库的BHA_Bool？Type参数，支持指定！

#还更新了用BHA_List的排版模拟二维布尔数组！


```

# 其他

```python

#二维数组的optimize与memory_usage（9.1.0新增）：

_2darr.optimize()

_2darr.memory_usage(detail=T)

输出格式：
 {
"占用(字节)": 【占用内存（字节）】,
"对比原生list节省": 【6位百分比】,
"对比numpy节省": 【6位百分比】}

#注：BoolHybridArray的memory_usage的百分比也变成了六位小数

#关闭哈希复用（9.4.0新增）

_2darr2 = BHA_List(BoolHybridArr((i%100 for i in range(1000)),hash_ = F) for i in range(1000))

#关闭哈希复用可以增快创建速度

#ResurrectMeta元类（9.5.0新增）

class MyClass(metaclass=ResurrectMeta):
	pass

#用装饰器给实例添加动态方法（9.6.0新增）：

arr = BoolHybridArr([T,F,T])

@arr
def toggle_range(self, start: int, end: int):
    """翻转从 start 到 end（含）的布尔值"""
    for i in range(start, end + 1):
        self[i] = not self[i]  # 通过 self 操作实例的元素
    print(f"翻转 {start}-{end} 后：", self)

arr.toggle_range(0,1)

print(arr)#输出：翻转 {0}-{1} 后：BoolHybridArr([False,True,True])

toggle_range(arr,0,1)#输出：翻转 {0}-{1} 后：BoolHybridArr([True,False,True])

#view方法（9.7.0新增）：

arr2 = arr.view()

arr2.extend([F,T])

arr2[2] = F

print(arr) #输出：BoolHybridArr([True,False,False,False,True])

#python 3.9以下的版本泛型、联合类型支持（9.8.0新增）

print(BHA_List[BoolHybridArray])#输出：bool_hybrid_array.BHA_List[bool_hybrid_array.BoolHybridArray]

print(BHA_List|BoolHybridArray)#输出：typing.Union[bool_hybrid_array.BHA_List, bool_hybrid_array.BoolHybridArray] （python 3.9以下）或 bool_hybrid_array.BHA_List|bool_hybrid_array.BoolHybridArray（python 3.10以上）

#BHA_Function动态创建函数（9.9.0新增）：

toggle_range = BHA_Function.string_define(
name = 'toggle_range',
text = 
'''
    for i in range(start, end + 1):
        self[i] = not self[i]  # 通过 self 操作实例的元素
    print(f"翻转 {start}-{end} 后：", self)''',
positional = ('self','start', 'end'),
default = {})
toggle_range([0,0,1],0,1)#输出：翻转 0-1 后： [True, True, 1]

#开放ProtectedBuiltinsDict类型（9.9.3+）

Dict = ProtectedBuiltinsDict({'1':1,'2':2},protected_names = ['1','3'],name = 'Dict')

Dict['2'] = 1

print(Dict) #输出：{'1': 1, '2': 1}

try:Dict['1'] = 2
except Exception as e:print(e) #输出：禁止修改内置常量：__Dict__['1']

#Ask_BHA和Create_BHA（9.10.0新增）：

arr = BoolHybridArr([T,F,F,F,T,T,F,F,F,T])
arr2 = BoolHybridArr([F,F,F,F,T,T,F,T,T,F])

arr3 = BHA_List([arr,arr2])

Create_BHA("single_bool_array",arr3)#自动生成single_bool_array.bha文件

print(Ask_BHA("single_bool_array"))

'''
输出：
BHA_List([
BoolHybridArr([True,False,False,False,True,True,False,False,False,True]),
BoolHybridArr([False,False,False,False,True,True,False,True,True,False]),
])
'''

#numba_opt函数优化（9.10.4版本新增）
try:numba_opt()
except:print("请先安装numba库！！！")

#int_array模块（9.10.10新增）：

max_num = (1 << 256) - 1
min_num = -max_num

# 1. IntHybridArray：257位完美存储
arr_hybrid = int_array.IntHybridArray([max_num, min_num, 123456], bit_length=257)
print("✅ IntHybridArray存储结果：")
print(f"最大值：{arr_hybrid[0]}")
print(f"最小值：{arr_hybrid[1]}")

# 2. NumPy：用最大的int64尝试存储（必然失败）
try:
    arr_np = np.array([max_num, min_num, 123456], dtype=np.int64)
    print("\n❌ NumPy存储结果：", arr_np)
except OverflowError as e:
    print(f"\n❌ NumPy存储失败：{e}")

#BHA_Queue（9.11.5版本新增）

q = BHA_Queue([T, F, T, T, F])

print(f"初始化队列: {q}")  # 输出：BHA_Queue([T,F,T,T,F])

q.enqueue(T)

q.enqueue(F)

print(f"入队2个元素后: {q}")  # 输出：BHA_Queue([T,F,T,T,F,T,F])

# 3. 出队（dequeue，均摊O(1)，仅首次触发转移）

print(f"第一次出队: {q.dequeue()}")  # 输出：T（触发 self.a → self.b 转移，仅1次）

print(f"第二次出队: {q.dequeue()}")  # 输出：F（直接从 self.b 弹出，纯O(1)）

print(f"出队2个元素后: {q}")  # 输出：BHA_Queue([T,T,F,T,F])

#float_array子包（9.11.15版本新增）

# 1. 初始化数组
f_arr = float_array.FloatHybridArray([1.1, 2.2, 3.3, 4.4, 5.5])

# 2. 获取元素
first_elem = f_arr[0]     # 获取第一个元素：BHA_Float(1.1)
print(f"第一个元素：{first_elem}")

# 3. 修改元素
f_arr[1] = 9.9            # 修改第二个元素为 9.9
print(f"修改后第二个元素：{f_arr[1]}")

# 4. 添加元素
f_arr.append(6.6)         # 追加元素 6.6
print(f"数组长度：{len(f_arr)}")  # 输出：6

# 5. 遍历数组
for elem in f_arr:
    print(f"数组元素：{elem}")

#namespace元类（9.11.15版本新增）
class BaseMathTools(metaclass = namespace):
    pi = 3.141
    def add(a,b):
        return a+b
    protected_names = ("pi","add")

class MathTools(BaseMathTools,metaclass = namespace):
    pi = 3.1415926535897932
    def mul(a,b):
        return a*b
    def sub(a,b):
        return a-b
    e = 2.718281828
    protected_names = (*BaseMathTools.protected_names,"e","sub","mul")

print(MathTools.mul(10,23))#输出：230


#布尔数组乘法（9.11.20版本新增）

# 定义两个超大二进制数（用BoolHybridArray存储）

# 二进制 1101（十进制13）

arr1 = BoolHybridArr([1,0,1,1])

# 二进制 1011（十进制11）

arr2 = BoolHybridArr([1,1,0,1])

# 直接相乘！

result = arr1 * arr2

print(result)  # 输出：BoolHybridArr([1,1,0,0,0,1,1]) → 二进制1100011 = 十进制143（13×11=143）

#__cin__魔法方法（9.11.21版本新增）

import ctypes

class Point:
    __slots__ = ("x", "y")
    def __init__(self,x = 0,y = 0):
        self.x,self.y = ctypes.c_int(x),ctypes.c_int(y)
    def __cin__(self,stream = cin):
        stream >> self.x >> self.y

point = Point()

cin >> point #输入：20 13

cout << point.x << ' ' << point.y #输出：20 13

#BHA_string（9.11.21版本新增）

string = BHA_string()

cin >> string#输入：bool-hybrid-array is efficient boolean array

cout << string#输出：bool-hybrid-array is efficient boolean array

#fstream和操纵符（9.11.34版本新增）

with ofstream("test.out") as fout:

    fout << "test" << endl

s = BHA_string()

with ifstream("test.out") as fin:

    fin >> s

cout  << setfill('f') << setw(10) << s << setfill(' ')#输出：fffffftest

#BHAX_Descriptor（9.12.0版本新增）

desc = BHAX_Descriptor("a.bhax")
desc.write_data(int_array.IntHybridArray([1, 2, 3]))
print(list(desc.read_data()))

# 浮点
desc = BHAX_Descriptor("b.bhax")
desc.write_data(float_array.FloatHybridArray([1.1, 2.2]))
data = desc.read_data()
print(data[0], data[1])

# 多维
desc = BHAX_Descriptor("c.bhax")
desc.write_data(BHA_List([
    BHA_List([int_array.IntHybridArray([1, 2]), int_array.IntHybridArray([3, 4])]),
    BHA_List([int_array.IntHybridArray([5, 6]), int_array.IntHybridArray([7, 8])]),
]))
data = desc.read_data()
print(list(data[1][0]))  # [5, 6]

#自创密码学工具链：umfs和mt_xor25

h = umfs(b"hello world!").hexdigest(bitn = 4406) #bitn：输出bit数，<9.13.1版本最大4406，超过会产生前导0，9.13.1版本起bitn可无限

print(h) #不同版本可能输出不同

#mt_xor25密码学随机数生成器（CSPRNG）

rng = mt_xor25()

"""
使用方式：
rng()：随机128位哈希
next(rng)：同rng()
for v in rng：无限迭代，每次循环v都是全新的随机128位哈希
rng.randrange()/rng.uniform()/rng.randint()/rng.getrandbits()：用法同random库，注意：不支持seed
"""

print(umfs(bytes(rng())).hexdigest(bitn = 4406)) #比裸调用更安全

#struct_array（9.13.0版本新增）

from bool_hybrid_array.struct_array import BHA_Struct, BHA_Vec2, BHA_RGBA

class Particle(BHA_Struct):
    __BHAStructAttrs__ = {
        "pos": BHA_Vec2,     # 嵌套 struct
        "age": int,          # IntHybridArray 列
        "mass": float,       # FloatHybridArray 列
        "alive": bool,       # BoolHybridArr 列
        "color": BHA_RGBA,   # 嵌套 struct
        "name": str,         # 退化成 list
    }

ps = Particle * 100

p = ps[0]
p.pos.x = 1.5
p.age = 0
p.mass = 9.8
p.alive = True
p.color.r = 255
p.name = "alpha"

ps[0], ps[1] = ps[1], ps[0]      # Python 风格交换正确

q = Particle(age=1, mass=1.0, name="beta")
ps.append(q)
ps.append({"pos": (0, 0), "age": 0, "mass": 0.0,
           "alive": False, "color": (0, 0, 0, 255), "name": "ghost"})

for p in ps:
    p.age += 1



```

## 性能优势

在包含100万个布尔值且只有10%为True的场景下
或在包含100万个布尔值且只有10%为False的场景下：

* ###### 普通Python列表：约占用1MB内存
* BoolHybridArray：约占用100KB内存（节省90%）
* 随机访问速度基本保持一致

## 版本历史

- **7.8.13**：PyPI上的初始版本，支持基本功能和自动存储优化
* **7.9.0**：添加TruesArray和FalsesArray
* **7.9.1**：修复介绍的bug，增加copy功能
* **7.9.2**：新增find()方法
* **7.10.0**：优化内部存储，重构密集部分（但使用还是一样）
* **7.10.1**：与运算和或运算增加异常提醒
* **7.10.2**：修复了之前所有版本的index错误
* **7.10.3**：新增rindex
* **7.10.4**：修正样例代码中的错误，增加index/rindex的空数组处理
* **7.10.5**：修复7.10.4版本index/rindex中size没加self的错误
* **7.10.6**：比7.10.0进一步优化内部储存
* **7.10.7**：新增arr.memory_usage方法查看是否优化，支持查看内存占用详情及优化建议，配合arr.optimize()实现存储自动调优
* **7.10.8**：增加cython加速
* **7.10.9**：修复之前所有版本的导入问题
* **7.10.10**：修复unit8溢出问题
* **7.10.11**：尝试修复memory_usage方法的错误
* **7.10.12**：尝试修复memory_usage方法的错误×2
* **7.10.13**：尝试修复memory_usage方法的错误×3
* **7.10.14**：尝试修复unit8溢出问题×2
* **7.10.15**：尝试修复unit8溢出问题×3
* **7.10.16**：修复unit8溢出问题×4+尝试修复memory_usage方法的错误×4
* **7.10.17**：尝试修复memory_usage方法的错误×4
* **7.10.18**：尝试修复memory_usage方法的错误×5
* **7.10.19**：尝试修复memory_usage方法的错误×6
* **7.10.20**：尝试修复memory_usage方法的错误×7
* **7.11.0**：新增int功能，把布尔数组转为int类型
* **7.12.0**：在优化函数中新增应对超级稀疏/超级密集情况的方案
* **7.13.0**：新增多种位运算功能
* **7.13.1**：修复普通左移参数为负数时结果错误
* **7.13.2**：修复左移时的sqrt问题，优化左移
* **7.13.3**：修复左移的问题
* **7.13.4**：优化左移
* **7.13.5**：优化sqrt
* **7.13.6**：修复7.13.5版本的SyntaxError
* **7.13.7**：优化`__int__`方法
* **7.14.0**：优化密集部分的运算速度
* **7.14.1**：优化多种位运算方法
* **7.14.2**：修复7.14.1版本的in的错误
* **7.14.3**：修复in的错误×2
* **7.14.4**：修复in的错误×3
* **7.14.5**：修复in的错误×4
* **7.14.6**：优化arr.large的类型
- **8.0.0**：兼容numpy数组
* **8.0.1**：修复8.0.0兼容numpy数组时没有形状参数的问题
* **8.0.2**：移除bool_hybrid_dtype，改用object
* **8.1.0**：利用ctypes加速密集部分的一些方法
* **8.1.1**：修复8.1.0版本中的“`AttributeError: '_CompactBoolArray' object has no attribute 'small'`”问题
* **8.1.2**：修复8.1.1版本中的“TypeError”
* **8.1.3**：修复8.1.2版本中的“NameError”问题
* **8.1.4**：修复8.1.3版本中的“TypeError”问题
* **8.1.5**：修复8.1.4版本中的“AttributeError”问题
* **8.2.0**：支持哈希
* **8.2.1**：修复8.2.0版本中的NameError
* **8.2.2**：修复8.2.1版本中的IndexError
- **9.0.0**：详情见上
* **9.0.1**：小更新，优化optimize方法
* **9.1.0**：新增二维数组的optimize与memory\_usage，优化二维数组的位运算，给BHA_Bool新增`__rand__、__ror__、__rxor__`等等
* **9.1.1**：修复9.1.0版本中的TypeError: unsupported operand type(s) for +: 'int' and 'method'错误
* **9.1.2**：修复9.1.1版本中的NameError: name 'equivalent\_numpy\_mem' is not defined错误
* **9.1.3**：修复9.1.2版本中的NameError: name 'need\_optimize' is not defined错误
* **9.2.0**：详情自己发现，提示：看看iter(arr)的返回值类型、调用一下二维数组的optimize、看看BHA\_Bool是不是一个类
* **9.3.0**：将find()返回值改为BHA_List，将BHA_Iterator变为可复用迭代器
* **9.4.0**：新增关闭哈希复用功能
* **9.4.1**：修复了被修改保护和被删除保护的bug
* **9.4.2**：修复被修改保护和被删除保护的bug×2
* **9.4.3**：移除只读辅类
* **9.4.4**：修复9.4.3版本中的NameError: name 'ReadOnlyAttribute' is not defined错误
* **9.4.5**：修复9.4.0~9.4.4数组索引访问重点TypeError: 'NoneType' object is not subscriptable
* **9.4.6**：让切片、位运算的哈希复用状态和self一致
* **9.5.0**：新增ResurrectMeta元类
* **9.5.1**：修复9.5.0版本中的ResurrectMeta的实例`__repr__`无限递归问题
* **9.5.2**：修复9.5.1版本中的ResurrectMeta的实例`__repr__`和`__str__`的无限递归问题
* **9.6.0**：新增用装饰器给实例添加动态方法的功能
* **9.6.1**：修复9.6.0中的参数传递问题
* **9.6.2**：可以使用BHA_Iterator
* **9.6.3**：修复常变量删除拦截的逻辑错误
* **9.6.4**：把常变量删除拦截的逻辑变得更可读
* **9.6.5**：修复TabError错误
* **9.6.6**：把常变量删除拦截变得更可读
* **9.6.7**：修复常变量删除拦截的逻辑错误
* **9.6.8**：修复常变量删除拦截的逻辑错误
* **9.6.9**：修复9.6.8中的SyntaxError错误
* **9.6.10**：修复9.6.9版本中的AttributeError错误
* **9.6.11**：修复9.6.10版本中的AttributeError: 'dict' object has no attribute '__dict__'. Did you mean: '__dir__'?错误
* **9.6.12**：修复AttributeError错误
* **9.6.13**：修复常变量删除拦截的逻辑错误
* **9.6.14**：修复常变量删除拦截的逻辑错误×2
* **9.6.15**：修复AttributeError错误
* **9.6.16**：修复常变量删除拦截的逻辑错误
* **9.6.17**：类标识错乱修复
* **9.6.18**：加快了迭代速度
* **9.6.19**：使用缓存加速
* **9.6.20**：修复TypeError: unhashable type: 'dict'错误
* **9.6.21**：修复RecursionError: maximum recursion depth exceeded while calling a Python object错误
* **9.6.22**：修复RecursionError: maximum recursion depth exceeded while calling a Python object错误×2
* **9.6.23**：增加了对bool\_hybrid_array.__dict__的防御机制
* **9.6.23.post1**：修复bool_hybrid_array.__dict__的防御机制的问题
* **9.6.23.post2**：修复bool_hybrid_array.__dict__的防御机制的问题×2
* **9.6.23.post3**：修复bool_hybrid_array.__dict__的防御机制的部分逻辑漏洞
* **9.6.23.post4**：修复bool_hybrid_array.__dict__的防御机制的部分逻辑漏洞×2
* **9.6.24**：和9.6.23.post4相同，正式版本发布
* **9.6.25**：增加了对`bool_hybrid_array`里的类的`__dict__`的防御机制
* **9.6.25.post1**：修复了“变量名不能以数字开头”的错误
* **9.6.26**：和9.6.25.post1相同，正式版本发布
* **9.6.27**：尝试修复T/F相等性判断错误
* **9.6.27.post1**：尝试修复T/F相等性判断错误×2
* **9.6.27.post2**：尝试修复T/F相等性判断错误×3
* **9.6.28**：和* **9.6.27.post2**相同，正式版本发布
* **9.6.29**：解决了密集区numpy的缓存同步问题和拷贝问题
* **9.6.30**：增加了”测试代码“文件
* **9.7.0**：增加了view方法
* **9.7.1**：修复`__array__`方法部分的错误
* **9.7.2**：修复9.7.1版本中numpy 2.0对`__array__`方法参数的警告
* **9.7.3**：解决np.array(arr)解释器莫名其妙退出的问题
* **9.8.0**：增加python 3.9以下的版本泛型、联合类型支持
* **9.8.1**：让python 3.10+版本泛型、联合类型分别为types.UnionType和types.GenericAlias
* **9.8.2**：修复9.8.1版本中联合类型返回值的错误
* **9.9.0**：新增BHA_Function动态创建函数的功能
* **9.9.1**：增加一下保护字典的保护名单
* **9.9.2**：加快了any和all的速度
* **9.9.3**：开放ProtectedBuiltinsDict类型
* **9.10.0**：新增Ask_BHA和Create_BHA
* **9.10.1**：修复TypeError: 'BoolHybridArray' object cannot be interpreted as an integer的错误
* **9.10.2**：解决多补前导零的问题
* **9.10.3**：解决少补前导零的问题
* **9.10.4**：新增numba_opt功能
* **9.10.5**：新增BHA_Opener工具包
* **9.10.6**：给Ask_BHA新增了mmap优化
* **9.10.7**：修复了RecursionError: maximum recursion depth exceeded错误
* **9.10.8**：给Create_BHA新增了mmap优化
* **9.10.9**：修复9.10.8版本中的NameError错误
* **9.10.10**：新增int_array模块
* **9.10.11**：修复NameError: name 'int_array' is not defined. Did you mean: 'bytearray'?的错误
* **9.10.12**：把find方法的返回值改为IntHybridArray
* **9.10.13**：给IntHybridArray新增多种列表操作
* **9.10.14**：修复IntHybridArray中因单个 0 导致所有数字位长被压缩到 1的问题
* **9.10.15**：修复IntHybridArray变成布尔数组的错误
* **9.10.16**：新增Python 3.14时的jit优化加速
* **9.10.17**：给保护字典添加`__import__`方法，支持from导入
* **9.10.18**：新增BoolHybridArray的序列化和反序列化支持
* **9.10.18.post1**：修复TypeError: cannot pickle 'itertools._tee' object错误
* **9.10.18.post2**：尝试修复“满屏错误”的问题
* **9.10.18.post3**：尝试修复“满屏错误”的问题×2
* **9.10.18.post4**：尝试修复“满屏错误”的问题×3
* **9.10.19**：和9.10.18.post4相同，正式版本发布
* **9.10.20**：优化性能，增加BHA_jit_log日志
* **9.10.21**：优化Ask_BHA，移除BHA_jit_log日志
* **9.10.22**：进一步优化Ask_BHA的性能
* **9.11.0**：新增对7.3.10以上版本的PyPy解释器的支持
* **9.11.1**：修复PyPy解释器下的保护机制过度保护bug
* **9.11.2**：尝试修复IntHybridArray索引修改的错误
* **9.11.3**：修复`NameError: name 'lst' is not defined. Did you mean: 'list'?`错误
* **9.11.4**：修复`TypeError: __dict__ must be set to a dictionary, not a 'IntHybridArray'`的错误
* **9.11.5**：新增BHA_Queue双栈实现队列
* **9.11.6**：修复从9.11.3版本开始cpython用户无法安装bool-hybrid-array包的问题
* **9.11.7**：修复TypeError: 'map' object is not reversible的错误
* **9.11.8**：增加了Windows系统Python3.14的C扩展优化
* **9.11.9**：修复BHA_Queue的bug，新增cin和cout（使用方式：a = ctypes.c_int();cin >> a;cout << a，支持各种ctypes类型、numpy标量）
* **9.11.10**：修复cin的AttributeError的错误
* **9.11.11**：新增cin对EOF的处理
* **9.11.12**：优化了IntHybridArray的`__setitem__`，新增了IntHybridArray的sort
* **9.11.13**：修复IndexError的错误
* **9.11.14**：新增BoolHybridArray数组的大小比较
* **9.11.15**：新增float_array子包和namespace元类
* **9.11.16**：修复SyntaxError错误
* **9.11.17**：优化IntHybridArray的sort方法
* **9.11.18**：修复TypeError的错误
* **9.11.19**：修复Cython优化
* **9.11.20**：新增布尔数组乘法
* **9.11.21**：新增`__cin__`魔法方法和BHA_string
* **9.11.22**：修复cout的换行错乱
* **9.11.23**：修复cout的换行错乱×2
* **9.11.24**：加速cout的速度
* **9.11.25**：公开mt_xor25和umfs，修复umfs的digest的错误
* **9.11.26**：修复mt_xor25的错误
* **9.11.27**：修复mt_xor25的错误×2
* **9.11.28**：修复Ask_BHA和Create_BHA的bug
* **9.11.29**：修复一些已知的问题
* **9.11.30**：修复语法错误
* **9.11.31**：修复namespace的继承错误
* **9.11.32**：修复9.11.31无法导入的错误
* **9.11.33**：修复了一些已知的问题
* **9.11.34**：支持fstream和操纵符
* **9.11.35**：修复fstream的错误
* **9.11.36**：修复fstream的错误×2
* **9.11.37**：修复fstream的错误×3
* **9.11.38**：修复了一些已知的问题
* **9.11.39**：优化性能
* **9.11.40**：修复一些已知的问题
* **9.11.41**：修复mt_xor25的bug
* **9.11.42**：优化性能
* **9.11.43**：优化性能
* **9.11.44**：尝试修复无法导入的bug
* **9.11.45**：尝试修复无法导入的bug*2
* **9.11.46**：尝试修复无法导入的bug*3
* **9.11.47**：尝试修复无法导入的bug*4
* **9.11.48**：尝试修复无法导入的bug*5
* **9.11.49**：修复序列化的bug，新增BHA_List.load和save方法
* **9.11.50**：修复上一个版本只有.whl的错误
* **9.12.0**：新增BHAX_Descriptor
* **9.12.1**：修复文档的错误
* **9.12.2**：修复一些已知的问题
* **9.12.3**：修复9.12.2版本中无法导入的问题
* **9.12.4**：修复上一个版本只有.whl的错误
* **9.12.5**：修复了一些已知的问题
* **9.12.6**：修复了一些已知的问题
* **9.12.7**：新增BHA_Queue的put、get、pop、popleft、append、appendleft方法
* **9.12.9**：优化性能，修复大量上古bug
* **9.12.10**：修复大量bug
* **9.12.11**：优化sort的性能
* **9.12.12**：加强umfs的安全性
* **9.12.13**：修复大量bug
* **9.12.14**：修复大量bug，优化性能
* **9.12.15**：修复了一些已知的问题****
* **9.12.16**：优化性能，修复bug
* **9.12.17**：修复bug，新增int_array.IntRSBTSet、float_array.FloatRSBTSet、twg_sort.twg_sort
* **9.12.18**：修复编译错误
* **9.12.19**：修复twg_sort崩溃问题
* **9.12.20**：尝试编译_cppiostream
* **9.12.21**：尝试修复twg_sort的错误
* **9.12.22**：修复twg_sort错误和优化性能
* **9.12.23**：修复float数组排序bug
* **9.12.24**：修复无法导入的bug
* **9.12.25**：优化umfs哈希安全性
* **9.13.0**：新增struct_array
* **9.13.1**：BHAX支持StructHybridArray，umfs哈希bitn可无限大，修复一些已知的问题
* **9.13.2**：新增BHA_lazy_sieve，用法：gen = BHA_lazy_sieve()，这里gen是一个无限迭代器，迭代他可以不断产出质数
* **9.13.3**：修复笔误


## **彩蛋：**

* Q：为什么要“密集+稀疏？”
* A：因为在做线性筛的时候遇到了个问题：密集数组太占内存，稀疏数组跑起来卡，所以就做了这个
* Q：为什么要“密集`numpy.ndarray`，稀疏`array.array`”？
* A：因为他本来只做线性筛，只修改数组，不`insert`、`pop`、`remove`;稀疏区长度变化平凡，要`numpy.ndarray`的“**修改就创建新实例**”的话那炸了，所以用`array.array`,密集区长度不变；所以可以用更高效的`numpy.ndarray`
* Q：为什么要有`TruesArray`/`FalsesArray`？直接用`BoolHybridArr([True]*n)`/`BoolHybridArr([False]*n)`不行吗？
* A：因为`BoolHybridArr([True]*n`)在计算`[True]*n`时如果n太大，那么列表的内存会溢出
* Q：**`BoolHybridArr`**和**`BoolHybridArray`**有什么区别？
* A：BoolHybridArray是本库中的**核心类**，所有函数都是围绕他进行的，但需要`split_index`,`size`,`is_sparse`；
  BoolHybridArr是一个**函数**，用于把一个可迭代对象转为`BoolHybridArray`类
* Q：为什么不建议把太大的本类型数组打印？
* A：虽然BoolHybridArray类型数组省内存，但字符串不省内存，一个`True`要4字节，一个`False`要5字节，连逗号都要占1字节（`numpy.ndarray`：我都比字符串省内存）
- Q：为什么使用在Windows终端使用PyPy时建议先调用`chcp 65001`再启动PyPy？
* A：因为本库有很多的的中文报错和打印，项目里也可能会有。Windows终端里的PyPy默认是GBK编码，有中文时会乱码。chcp 65001可以切换到UTF-8编码，防止乱码。也可以把print换成cout防止乱码


### bool-hybrid-array
🔥 全网下载140K+，但GitHub星标≈0的「神秘Python包」🔥

#### 为啥这么多人下载还没人来GitHub？
我也不知道😭 可能大家下载完就把我忘了，求各位大佬来看看孩子吧！

#### 今日目标
📌 星标破50：出详细教程+性能对比视频
📌 星标破100：直播在线改bug（你提我改，绝不耍赖）


## 源代码和原理

请见[来看看我自己的布尔数组吧！](https://code.xdf.cn/freecode/editor?no=80cd07aa023fb2448069e6d8dd50bb5d&type=2&org=code)
或[Github仓库](https://github.com/BKsell/bool-hybrid-array.git)

## 许可证

本项目采用**自9.12.7版本开始采用Apache-2.0许可证**，详情参见**`LICENSE`**文件。

```
   Copyright 2026 蔡靖杰

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
```

**9.12.8 版本起**使用者也可选择 **MulanPSL‑2.0**，详情参见**`LICENSE‑MulanPSL2`**文件

```
    Copyright (c) 2026 蔡靖杰
    bool-hybrid-array 遵循 Mulan PSL v2 许可证。
    您可以依据 Mulan PSL v2 的条款使用本项目。
    Mulan PSL v2 可通过如下地址获取：

        http://license.coscl.org.cn/MulanPSL2

    本软件按“原样”提供，不提供任何明示或默示保证，
    包括但不限于对适销性、特定用途适用性和非侵权性的保证。
    详见 Mulan PSL v2。
```
