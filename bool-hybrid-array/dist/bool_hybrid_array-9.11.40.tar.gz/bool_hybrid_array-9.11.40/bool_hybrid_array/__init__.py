# -*- coding: utf-8 -*-
import sys
from types import ModuleType,FunctionType
from . import core
from .core import __builtins__,builtins
try:from . import int_array,float_array
except:pass
__version__ = "9.11.40"
public_objects = []
for name in dir(core):
    if not name.startswith("_") or (name.endswith("__") and name.startswith("__")):
        obj = getattr(core, name)
        public_objects.append(name)
__all__ = public_objects + ["__version__","__builtins__","builtins","core","builtins","__dict__","int_array","float_array"]
globals().update({
    name: getattr(core, name)
    for name in public_objects
})
try:
    sys.modules[__name__] =  ProtectedBuiltinsDict(globals())
    sys.modules[__name__].name = __name__
    sys.modules[__name__+'.core'] = ProtectedBuiltinsDict(core.__dict__,name = f'{__name__}.core')
    __dict__ = ProtectedBuiltinsDict(globals())
    sys.modules[__name__].int_array = ProtectedBuiltinsDict(int_array.__dict__,name = __name__+'.int_array')
    sys.modules[__name__].float_array = ProtectedBuiltinsDict(float_array.__dict__,name = __name__+'.float_array')
    core.__dict__ = ProtectedBuiltinsDict(core.__dict__)
except:
    pass

